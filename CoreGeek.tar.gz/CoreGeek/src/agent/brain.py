"""Goal-method-plan battle brain.

The game is simultaneous: a locally good move can be a bad turn when two
heroes reserve the same cell or exchange positions.  This module therefore
keeps the three planning levels explicit:

* :class:`Goal` is the stable catalogue of things the team can achieve.
* :class:`Method` assigns one or more role tasks to a goal.
* :class:`Plan` is one concrete, conflict-resolved set of commands for this
  turn.  It has a conservative lower bound and an optimistic upper bound.

Plans are enumerated only until a small time budget expires.  Whenever a
plan's optimistic upper bound is no better than the current best conservative
score it is pruned.  This is deliberately a bounded anytime search: the
agent always has a legal fallback even when the judge sends a large map.
"""

from __future__ import annotations

import math
import re
import threading
import time
from dataclasses import dataclass, field
from itertools import permutations, product
from typing import Any, Iterable, Mapping

from .grid import next_step
from .protocol import (
    DAY_ROUNDS,
    HERO_TYPES,
    LAND,
    MAX_HEALTH_BY_KIND,
    ORE_TYPES,
    PIONEER,
    ROBOT_SCORE,
    SHOP_PRICES,
    STATION,
    TASK_POINT_TYPES,
    TOWER_TYPES,
    WALL,
    WALL_MATERIAL,
    WEAPON_BUILD_COST,
    WORKER,
    Pos,
    Turn,
    Unit,
    accept_task_command,
    attack_command,
    build_command,
    buy_command,
    collect_command,
    distance,
    drop_command,
    move_command,
    remove_command,
    sell_command,
    submit_answer_command,
    summon_treasure_command,
    use_command,
)

PLANNING_BUDGET_SECONDS = 1.5
LEGACY_DEFENSE_PREP_ROUNDS = 12
_NEIGHBOUR_STEPS = (
    (-1, -1), (-1, 0), (-1, 1), (0, -1),
    (0, 1), (1, -1), (1, 0), (1, 1),
)
_ACTIONS = {
    "move", "attack", "sell", "buy", "build", "remove", "acceptTask",
    "submitAnswer", "summonTreasure", "use", "drop", "collect",
}
_TREASURE_ITEMS = (
    "AcientTablet", "StarSand", "FlameBreath", "FrostPotion",
    "ThornAmulet", "IronWhistle",
)
_TREASURE_ALIASES = {
    "古符石板": "AcientTablet",
    "星辰之沙": "StarSand",
    "烈焰之息": "FlameBreath",
    "寒霜药剂": "FrostPotion",
    "荆棘护符": "ThornAmulet",
    "回音铁哨": "IronWhistle",
}
_COORD_RE = re.compile(r"\(\s*(\d{1,2})\s*[,，]\s*(\d{1,2})\s*\)")
_XY_RE = re.compile(r"x\s*[:=]\s*(\d{1,2}).{0,30}?y\s*[:=]\s*(\d{1,2})", re.I | re.S)

# Fixed goal catalogue.  Priorities are recomputed from the turn, but the
# strategic vocabulary itself never changes during a match.
GOAL_CATALOG = (
    "save-base", "defend", "night-guard", "build-weapons", "build-walls",
    "upgrade-repair", "self-evolution-task", "treasure", "use-items",
    "trade", "collect", "shop", "remove-wall", "drop-junk",
    "safe-positioning",
)

# Keep aliases runtime-compatible with the older Python used by some judge
# containers; annotations above are still precise enough for type checkers.
Command = dict
CommandMap = dict


@dataclass(frozen=True)
class Goal:
    goal_id: str
    name: str
    priority: float
    data: tuple[Any, ...] = ()


@dataclass(frozen=True)
class Assignment:
    """One role/tower reservation and its alternative commands."""

    owner_id: int
    choices: tuple[CommandMap, ...]
    locks: frozenset[int] = frozenset()
    value: float = 0.0


@dataclass(frozen=True)
class Method:
    goal: Goal
    name: str
    assignments: tuple[Assignment, ...]
    ideal_gain: float


@dataclass(frozen=True)
class Plan:
    goal: Goal
    method: Method
    commands: CommandMap
    lower_bound: float
    upper_bound: float
    conflicts: tuple[str, ...] = ()


@dataclass
class PlannerState:
    day: int = -1
    llm_calls: int = 0
    folk_history: str = ""
    treasure_target: Pos | None = None
    treasure_items: tuple[str, ...] = ()
    treasure_claimed: bool = False
    summons_used_today: int = 0
    last_plan: Plan | None = None
    failed_until: dict[tuple[int, str], int] = field(default_factory=dict)
    # 角色 → 最近一次 acceptTask 的回合号，防止重复接受
    last_accept_task_round: dict[int, int] = field(default_factory=dict)
    # 角色 → 上一轮位置，用于检测振荡
    last_pos: dict[int, Pos] = field(default_factory=dict)
    # 角色 → 上上轮位置，用于检测更复杂的振荡模式
    prev_prev_pos: dict[int, Pos] = field(default_factory=dict)
    # 角色 → (矿点, 连续采集轮数)，用于检测矿枯竭
    collect_tracker: dict[int, tuple[Pos, int]] = field(default_factory=dict)

    def observe(self, turn: Turn) -> None:
        day = (turn.round_no - 1) // 130
        if day != self.day:
            self.day = day
            self.llm_calls = 0
            self.summons_used_today = 0
        self.failed_until = {
            key: round_no
            for key, round_no in self.failed_until.items()
            if round_no >= turn.round_no
        }
        if self.last_plan is not None:
            for unit_id, success in turn.last_action_results.items():
                if success:
                    continue
                command = self.last_plan.commands.get(unit_id)
                if command is not None:
                    action = str(command.get("action") or "")
                    if action:
                        # acceptTask 失败后冷却 10 轮，其他动作冷却 3 轮
                        cooldown = 10 if action == "acceptTask" else 3
                        self.failed_until[(unit_id, action)] = turn.round_no + cooldown
        if turn.news.folk:
            self.folk_history = (self.folk_history + " " + turn.news.folk)[-12000:]
        if turn.llm_resp and not turn.phase_task:
            self.folk_history = (self.folk_history + " " + turn.llm_resp)[-12000:]
        if turn.last_treasure_result == 1:
            self.treasure_claimed = True
        self._read_treasure_clues()
        # 记录角色当前位置，用于下一轮振荡检测
        new_pos = {unit.unit_id: unit.pos for unit in turn.controllable()}
        self.prev_prev_pos = {
            rid: self.last_pos[rid] for rid in new_pos
            if rid in self.last_pos
        }
        self.last_pos = new_pos

    def action_blocked(self, unit_id: int, command: Command, round_no: int) -> bool:
        action = str(command.get("action") or "")
        return self.failed_until.get((unit_id, action), -1) >= round_no

    def _read_treasure_clues(self) -> None:
        if self.treasure_claimed:
            return
        text = self.folk_history
        match = _COORD_RE.search(text) or _XY_RE.search(text)
        if match:
            self.treasure_target = Pos(int(match.group(1)), int(match.group(2)))
        found_names = [item for item in _TREASURE_ITEMS if item in text]
        found_names.extend(alias for alias in _TREASURE_ALIASES if alias in text and _TREASURE_ALIASES[alias] not in found_names)
        found = tuple(_TREASURE_ALIASES.get(item, item) for item in found_names)
        if found:
            self.treasure_items = found


class GoalMethodPlanPlanner:
    def __init__(self, state: PlannerState | None = None) -> None:
        self.state = state or PlannerState()
        self.goal_catalog = GOAL_CATALOG

    def decide(self, payload: Mapping[str, Any]) -> dict[str, Any]:
        turn = Turn.load(payload)
        self.state.observe(turn)
        if turn.round_no <= 130:
            commands: CommandMap = {}
            if turn.is_day:
                self._legacy_day(turn, commands)
            else:
                self._legacy_night(turn, commands)
            # 兜底：为未被 legacy 策略覆盖的角色生成命令
            station = turn.station()
            for role in turn.controllable():
                if role.unit_id not in commands:
                    if station is not None and distance(role.pos, station.pos) > 2:
                        step = self._step_to_stand(turn, role, station.pos)
                        if step:
                            commands[role.unit_id] = move_command(step)
                            continue
                    # 只有 worker 才能执行 remove 命令
                    if role.kind == WORKER:
                        wall_to_remove = self._adjacent_removable_wall(turn, role)
                        if wall_to_remove is not None:
                            commands[role.unit_id] = remove_command(wall_to_remove)
                            continue
                    # pioneer 尝试走向任务点或资源点
                    if role.kind == PIONEER:
                        step = self._legacy_pioneer_explore(turn, role, commands)
                        if step is not None:
                            commands[role.unit_id] = move_command(step)
                            continue
                    commands[role.unit_id] = {}
            self._sanitize_commands(turn, commands)
            return {
                "roleCommandMap": {str(key): value for key, value in commands.items()},
                "prompt": "",
                "executeCmd": "",
            }
        commands, chosen = self._choose_plan(turn)
        self.state.last_plan = chosen
        for unit_id, command in commands.items():
            if command.get("action") == "use" and "RobotSummonOrder" in str(command.get("name", "")):
                self.state.summons_used_today += 1
            if command.get("action") == "acceptTask":
                self.state.last_accept_task_round[unit_id] = turn.round_no
        self._sanitize_commands(turn, commands)
        prompt = self._task_prompt(turn)
        return {
            "roleCommandMap": {str(key): value for key, value in commands.items()},
            "prompt": prompt,
            "executeCmd": self._task_command(turn),
        }

    def _sanitize_commands(self, turn: Turn, commands: CommandMap) -> None:
        """安全过滤：移除违反游戏规则的命令，防止 COMMAND_ERROR 导致被淘汰。"""
        role_kinds = {unit.unit_id: unit.kind for unit in turn.ours}
        # worker 专属动作集合
        worker_only = {"build", "remove", "collect"}
        # 收集所有被用作 controllerId 的角色 ID
        controller_ids: set[int] = set()
        for command in commands.values():
            if not command:
                continue
            if command.get("action") == "attack":
                cid = command.get("controllerId")
                if cid is not None:
                    try:
                        controller_ids.add(int(cid))
                    except (TypeError, ValueError):
                        pass
        for unit_id, command in list(commands.items()):
            if not command:
                continue
            action = str(command.get("action") or "")
            kind = role_kinds.get(unit_id, "")
            # 非 worker 不能执行 build/remove/collect
            if action in worker_only and kind != WORKER:
                commands[unit_id] = {}
                continue
            # 非 hero 角色不能执行 move/acceptTask 等
            if action and kind not in HERO_TYPES and action not in {"attack"}:
                commands[unit_id] = {}
                continue
            # controller 不能同时执行其他动作（move/collect/build/use 等）
            if unit_id in controller_ids and action not in ("",):
                commands[unit_id] = {}
                continue
            # 移除已被冷却的动作
            if self.state.action_blocked(unit_id, command, turn.round_no):
                commands[unit_id] = {}

    # ----- Compatibility phase: the original demo policy is intentionally
    # kept unchanged for the first 130 rounds.  Round 131 is the first turn
    # that enters the goal-method-plan planner below.

    def _legacy_day(self, turn: Turn, commands: CommandMap) -> None:
        sites = self._tower_sites(turn)
        wall_targets = self._wall_order(turn)
        standing_towers = {unit.pos for unit in turn.weapons()}
        standing_walls = {unit.pos for unit in turn.walls()}
        occupied = turn.occupied_cells()
        towers_missing = [pos for pos in sites if pos not in standing_towers]
        walls_missing = [pos for pos in wall_targets if pos not in standing_walls]
        # These are retained as separate lists to preserve the original
        # policy's notion of reserving a construction cell per worker.
        free_towers = [pos for pos in towers_missing if pos not in occupied]
        free_walls = [pos for pos in walls_missing if pos not in occupied]

        # The log showed workers still travelling around the perimeter when
        # night started, so the first night spent several turns just moving
        # controllers to their weapons.  Reserve the final 12 daytime turns
        # for defensive positioning while retaining the original opening
        # construction policy before that window.
        if (
            turn.round_no >= DAY_ROUNDS - LEGACY_DEFENSE_PREP_ROUNDS + 1
            and len(turn.weapons()) >= min(3, len(turn.controllable()))
        ):
            self._legacy_prepare_defense(turn, commands)
            return

        claimed: set[Pos] = set()
        for role in turn.workers():
            self._legacy_worker_day(
                turn, role, sites, free_towers, free_walls, claimed, commands,
            )
        # pioneer 在建设阶段走向任务点或协助防御位
        for role in turn.pioneers():
            if role.unit_id in commands:
                continue
            # 优先走向任务点接受任务
            task_points = turn.own_task_points()
            if task_points:
                nearest_task = min(task_points, key=lambda pos: distance(role.pos, pos))
                if distance(role.pos, nearest_task) <= 1:
                    # 检查 acceptTask 冷却
                    last_accept = self.state.last_accept_task_round.get(role.unit_id, -100)
                    if turn.round_no - last_accept >= 10:
                        commands[role.unit_id] = accept_task_command()
                        self.state.last_accept_task_round[role.unit_id] = turn.round_no
                        continue
                    # 冷却中：走向武器塔附近待命，不空转
                else:
                    step = self._legacy_step_toward(turn, role, nearest_task, claimed)
                    if step is not None:
                        commands[role.unit_id] = move_command(step)
                        continue
            # 没有任务点或冷却中时走向武器塔附近待命
            weapons = turn.weapons()
            if weapons:
                nearest_weapon = min(weapons, key=lambda w: distance(role.pos, w.pos))
                if distance(role.pos, nearest_weapon.pos) > 1:
                    step = self._legacy_step_toward(turn, role, nearest_weapon.pos, claimed)
                    if step is not None:
                        commands[role.unit_id] = move_command(step)

    def _legacy_prepare_defense(self, turn: Turn, commands: CommandMap) -> None:
        claimed: set[Pos] = set()
        for role, tower in self._legacy_tower_pairs(turn):
            if distance(role.pos, tower.pos) <= 1:
                continue
            step = self._legacy_step_toward(turn, role, tower.pos, claimed)
            if step is None:
                # The original path finder can return the same first step for
                # several heroes.  During this short preparation window, use
                # a legal improving neighbour as a reservation-aware fallback
                # so one blocked reservation does not strand a controller.
                step = self._legacy_conflict_free_step(turn, role, tower.pos, claimed)
            if step is not None:
                commands[role.unit_id] = move_command(step)

    def _legacy_conflict_free_step(
        self,
        turn: Turn,
        role: Unit,
        target: Pos,
        claimed: set[Pos],
    ) -> Pos | None:
        blocked = turn.blocked(role)
        candidates = []
        for dx, dy in _NEIGHBOUR_STEPS:
            candidate = Pos(role.pos.x + dx, role.pos.y + dy)
            if not turn.land(candidate) or candidate in blocked or candidate in claimed:
                continue
            candidates.append(candidate)
        if not candidates:
            return None
        improving = [candidate for candidate in candidates if distance(candidate, target) < distance(role.pos, target)]
        choices = improving or candidates
        step = min(choices, key=lambda pos: (distance(pos, target), pos.x, pos.y))
        claimed.add(step)
        return step

    def _legacy_worker_day(
        self,
        turn: Turn,
        role: Unit,
        sites: tuple[Pos, ...],
        towers_missing: list[Pos],
        walls_missing: list[Pos],
        claimed: set[Pos],
        commands: CommandMap,
    ) -> None:
        if towers_missing and turn.gold >= WEAPON_BUILD_COST:
            for index, site in enumerate(sites):
                if site in towers_missing and site not in claimed:
                    self._legacy_build_or_walk(
                        turn, role, site, TOWER_TYPES[index], claimed, commands,
                    )
                    return
        if not walls_missing:
            # 没有建筑任务时继续采集资源
            self._legacy_mine(turn, role, claimed, commands)
            return

        stones = role.count(WALL_MATERIAL)
        mine = self._legacy_adjacent_mine(turn, role, claimed)
        if mine is not None and stones < 6:
            commands[role.unit_id] = collect_command(mine)
            claimed.add(mine)
            return
        if stones:
            for site in walls_missing:
                if site not in claimed:
                    self._legacy_build_or_walk(turn, role, site, WALL, claimed, commands)
                    return
            return
        self._legacy_mine(turn, role, claimed, commands)

    def _legacy_night(self, turn: Turn, commands: CommandMap) -> None:
        claimed: set[Pos] = set()
        used_targets: set[Pos] = set()
        # 记录被用作 controller 的角色 ID，防止同一角色同时攻击和移动
        controller_ids: set[int] = set()
        paired_roles: set[int] = set()
        # 先处理武器塔攻击和英雄就位
        robots = [robot for robot in turn.robots if robot.health > 0]
        has_targets = bool(robots)
        for role, tower in self._legacy_tower_pairs(turn):
            paired_roles.add(role.unit_id)
            if distance(role.pos, tower.pos) <= 1:
                if tower.cooldown > 0:
                    # 角色在塔旁待命，不分配其他动作
                    commands[role.unit_id] = {}
                    continue
                target = self._legacy_attack_target(turn, tower, avoid=used_targets)
                if target is not None:
                    commands[tower.unit_id] = attack_command(role.unit_id, (target,))
                    used_targets.add(target)
                    # 标记 controller：该角色本回合不能执行其他动作
                    controller_ids.add(role.unit_id)
                    commands[role.unit_id] = {}
                else:
                    # 没有攻击目标时，worker 可以做其他事
                    if role.kind == WORKER and not has_targets:
                        # 尝试卖矿或修墙
                        if self._legacy_night_worker_task(turn, role, claimed, commands):
                            continue
                    commands[role.unit_id] = {}
                continue
            step = self._legacy_step_toward(turn, role, tower.pos, claimed)
            if step is not None:
                commands[role.unit_id] = move_command(step)
        # 未配对武器塔的 hero 走向最近武器塔
        weapons = turn.weapons()
        if weapons:
            for role in turn.controllable():
                if role.unit_id in paired_roles:
                    continue
                # 受伤的 hero 优先使用药品
                if role.count("Medicine") and role.health < role.max_health() * 0.55:
                    commands[role.unit_id] = use_command("Medicine")
                    paired_roles.add(role.unit_id)
                    continue
                nearest = min(weapons, key=lambda w: distance(role.pos, w.pos))
                if distance(role.pos, nearest.pos) <= 1:
                    # 已在武器塔旁，尝试攻击
                    if nearest.cooldown <= 0:
                        target = self._legacy_attack_target(turn, nearest, avoid=used_targets)
                        if target is not None:
                            commands[nearest.unit_id] = attack_command(role.unit_id, (target,))
                            used_targets.add(target)
                            controller_ids.add(role.unit_id)
                            commands[role.unit_id] = {}
                            continue
                    # 没有攻击目标时，worker 可以做其他事
                    if role.kind == WORKER and not has_targets:
                        if self._legacy_night_worker_task(turn, role, claimed, commands):
                            continue
                    commands[role.unit_id] = {}
                    continue
                step = self._legacy_step_toward(turn, role, nearest.pos, claimed)
                if step is not None:
                    commands[role.unit_id] = move_command(step)

    def _legacy_tower_pairs(self, turn: Turn) -> tuple[tuple[Unit, Unit], ...]:
        # This is the original role-to-weapon zip pairing.
        return tuple(zip(turn.controllable(), turn.weapons()))

    def _legacy_night_worker_task(
        self,
        turn: Turn,
        role: Unit,
        claimed: set[Pos],
        commands: CommandMap,
    ) -> bool:
        """夜间无攻击目标时为 worker 生成有意义任务：卖矿、修墙或采集。"""
        # 背包有矿石时走向 vendor 出售
        carried = [ore for ore in ORE_TYPES if role.count(ore)]
        if carried:
            vendor = self._closest_neutral(turn, "vendor")
            if vendor is not None:
                if distance(role.pos, vendor) <= 1:
                    ore = max(carried, key=lambda item: turn.vendor_prices.get(item, 1))
                    commands[role.unit_id] = sell_command(ore, role.count(ore))
                    return True
                step = self._legacy_step_toward(turn, role, vendor, claimed)
                if step is not None:
                    commands[role.unit_id] = move_command(step)
                    return True
        # 有 WallFixer 时修墙
        if role.count("WallFixer"):
            for wall in turn.walls():
                if wall.health >= wall.max_health() * 0.75:
                    continue
                if distance(role.pos, wall.pos) <= 1:
                    commands[role.unit_id] = use_command("WallFixer", wall.pos)
                    return True
                step = self._legacy_step_toward(turn, role, wall.pos, claimed)
                if step is not None:
                    commands[role.unit_id] = move_command(step)
                    return True
        return False

    def _legacy_pioneer_explore(
        self,
        turn: Turn,
        pioneer: Unit,
        commands: CommandMap,
    ) -> Pos | None:
        """legacy 阶段为 pioneer 生成有意义的移动：白天优先走向任务点，夜间前往武器塔防守。"""
        if not turn.is_day:
            # 夜间前往最近武器塔，避免被机器人击杀
            weapons = turn.weapons()
            if weapons:
                nearest_weapon = min(weapons, key=lambda w: distance(pioneer.pos, w.pos))
                if distance(pioneer.pos, nearest_weapon.pos) > 1:
                    step = self._legacy_step_toward(turn, pioneer, nearest_weapon.pos, set())
                    if step is not None:
                        return step
            station = turn.station()
            if station is not None and distance(pioneer.pos, station.pos) > 2:
                step = self._legacy_step_toward(turn, pioneer, station.pos, set())
                if step is not None:
                    return step
            return None
        # 白天优先走向可用的任务点
        task_points = turn.own_task_points()
        if task_points:
            nearest_task = min(task_points, key=lambda pos: distance(pioneer.pos, pos))
            step = self._legacy_step_toward(turn, pioneer, nearest_task, set())
            if step is not None:
                return step
        # 没有任务点时走向武器塔附近待命
        weapons = turn.weapons()
        if weapons:
            nearest_weapon = min(weapons, key=lambda w: distance(pioneer.pos, w.pos))
            if distance(pioneer.pos, nearest_weapon.pos) > 1:
                step = self._legacy_step_toward(turn, pioneer, nearest_weapon.pos, set())
                if step is not None:
                    return step
        return None

    def _pioneer_task_step(self, turn: Turn, pioneer: Unit) -> Pos | None:
        """planner 阶段为 pioneer 生成走向任务点的步。夜间不外出，优先走向武器塔防守。"""
        if not turn.is_day:
            # 夜间前往最近武器塔，避免被机器人击杀
            weapons = turn.weapons()
            if weapons:
                nearest_weapon = min(weapons, key=lambda w: distance(pioneer.pos, w.pos))
                if distance(pioneer.pos, nearest_weapon.pos) > 1:
                    return self._step_to_stand(turn, pioneer, nearest_weapon.pos)
            station = turn.station()
            if station is not None and distance(pioneer.pos, station.pos) > 2:
                return self._step_to_stand(turn, pioneer, station.pos)
            return None
        task_points = turn.own_task_points()
        if task_points:
            nearest_task = min(task_points, key=lambda pos: distance(pioneer.pos, pos))
            return self._step_to_stand(turn, pioneer, nearest_task)
        station = turn.station()
        if station is not None and distance(pioneer.pos, station.pos) > 2:
            return self._step_to_stand(turn, pioneer, station.pos)
        return None

    def _legacy_attack_target(self, turn: Turn, tower: Unit, *, avoid: Iterable[Pos] = ()) -> Pos | None:
        reach = tower.range_of_attack()
        targets = [
            robot for robot in turn.robots
            if robot.health > 0 and distance(tower.pos, robot.pos) <= reach
        ]
        if not targets:
            return None
        reserved = set(avoid)
        unclaimed = [robot for robot in targets if robot.pos not in reserved]
        if unclaimed:
            targets = unclaimed
        nearest = min(
            targets,
            key=lambda robot: (distance(tower.pos, robot.pos), robot.robot_id),
        )
        return nearest.pos

    def _legacy_build_or_walk(
        self,
        turn: Turn,
        role: Unit,
        target: Pos,
        name: str,
        claimed: set[Pos],
        commands: CommandMap,
    ) -> None:
        if role.pos != target and distance(role.pos, target) <= 1:
            commands[role.unit_id] = build_command(target, name)
            claimed.add(target)
            return
        step = self._legacy_step_toward(turn, role, target, claimed)
        if step is not None:
            commands[role.unit_id] = move_command(step)

    def _legacy_adjacent_mine(
        self,
        turn: Turn,
        role: Unit,
        claimed: Iterable[Pos] = (),
    ) -> Pos | None:
        reserved = set(claimed)
        mines = sorted(
            (
                mine for mine in turn.resource_mines(WALL_MATERIAL)
                if (
                    role.pos != mine
                    and distance(role.pos, mine) <= 1
                    and mine not in reserved
                )
            ),
            key=lambda pos: (distance(role.pos, pos), pos.x, pos.y),
        )
        return mines[0] if mines else None

    def _legacy_mine(
        self,
        turn: Turn,
        role: Unit,
        claimed: set[Pos],
        commands: CommandMap,
    ) -> bool:
        if role.backpack_full:
            # 背包满时走向商店出售资源
            vendor = self._closest_neutral(turn, "vendor")
            if vendor is not None:
                if distance(role.pos, vendor) <= 1:
                    carried = [ore for ore in ORE_TYPES if role.count(ore)]
                    if carried:
                        ore = max(carried, key=lambda item: turn.vendor_prices.get(item, 1))
                        commands[role.unit_id] = sell_command(ore, role.count(ore))
                        return True
                else:
                    step = self._legacy_step_toward(turn, role, vendor, claimed)
                    if step is not None:
                        commands[role.unit_id] = move_command(step)
                        return True
            return False
        # 城墙未建完时优先采集石头，否则采集所有矿石
        wanted = WALL_MATERIAL if self._missing_wall_targets(turn) else None
        mines = sorted(
            (pos for pos in turn.resource_mines(wanted) if pos not in claimed),
            key=lambda pos: (distance(role.pos, pos), pos.x, pos.y),
        )
        for mine in mines:
            if role.pos != mine and distance(role.pos, mine) <= 1:
                # 检测是否在同一矿点采集过久（可能已枯竭）
                tracker = self.state.collect_tracker.get(role.unit_id)
                if tracker and tracker[0] == mine and tracker[1] >= 3:
                    continue
                commands[role.unit_id] = collect_command(mine)
                self.state.collect_tracker[role.unit_id] = (mine, (tracker[1] + 1) if tracker and tracker[0] == mine else 1)
                claimed.add(mine)
                return True
            step = self._legacy_step_toward(turn, role, mine, claimed)
            if step is not None:
                commands[role.unit_id] = move_command(step)
                return True
        return False

    def _legacy_step_toward(
        self,
        turn: Turn,
        role: Unit,
        target: Pos,
        claimed: set[Pos],
        *,
        inside_only: bool = False,
    ) -> Pos | None:
        prev_pos = self.state.last_pos.get(role.unit_id)
        prev_prev = self.state.prev_prev_pos.get(role.unit_id)
        for stand in self._legacy_stand_cells(turn, role, target, claimed, inside_only):
            if stand == role.pos:
                return None
            step = next_step(turn, role, stand)
            if step is None or step in claimed:
                continue
            # 振荡检测：跳过会回到上一轮或上上轮位置的步
            if prev_pos is not None and step == prev_pos and prev_pos != role.pos:
                continue
            if prev_prev is not None and step == prev_prev and prev_prev != role.pos and prev_prev != prev_pos:
                continue
            claimed.add(step)
            return step
        return None

    def _legacy_stand_cells(
        self,
        turn: Turn,
        role: Unit,
        target: Pos,
        claimed: set[Pos],
        inside_only: bool = False,
    ) -> list[Pos]:
        station = turn.station()
        footprint = turn.footprint(station) if station else ()
        blocked = turn.blocked(role)
        cells = [
            Pos(target.x + dx, target.y + dy)
            for dx, dy in _NEIGHBOUR_STEPS
            if turn.land(Pos(target.x + dx, target.y + dy))
            and Pos(target.x + dx, target.y + dy) not in blocked
            and (Pos(target.x + dx, target.y + dy) == role.pos or Pos(target.x + dx, target.y + dy) not in claimed)
            and (not inside_only or _footprint_distance(Pos(target.x + dx, target.y + dy), footprint) <= 1)
        ]
        cells.sort(key=lambda pos: (_footprint_distance(pos, footprint), pos.x, pos.y))
        return cells

    # ----- Level 1: stable goals, reprioritised from the current world state

    def _goals(self, turn: Turn) -> list[Goal]:
        goals: list[Goal] = []
        station = turn.station()
        if station is not None:
            max_hp = station.max_health() or 1500
            ratio = station.health / max_hp
            if ratio < 0.82:
                goals.append(Goal("save-base", "keep the base alive", 950 + (1 - ratio) * 300))

        if not turn.is_day:
            robots = [robot for robot in turn.robots if robot.health > 0]
            enemies = [unit for unit in turn.enemies if unit.alive]
            if robots or enemies:
                # 夜间防御优先级随机器数量和基地血量提升
                defend_priority = 820 + len(robots) * 8
                if station is not None:
                    defend_priority += int((1 - station.health / (station.max_health() or 1500)) * 200)
                goals.append(Goal("defend", "defend against robots and enemy units", defend_priority))
            elif turn.weapons():
                goals.append(Goal("night-guard", "put heroes beside weapons", 500))
            # 夜间也可以修墙和升级
            if self._has_upgrade_or_repair(turn):
                goals.append(Goal("upgrade-repair", "upgrade or repair the most valuable building", 700))
        else:
            if len(turn.weapons()) < 3 and turn.gold >= WEAPON_BUILD_COST:
                goals.append(Goal("build-weapons", "build up to three weapon emplacements", 620))
            if self._missing_wall_targets(turn):
                stone = sum(unit.count(WALL_MATERIAL) for unit in turn.workers())
                if stone:
                    goals.append(Goal("build-walls", "close the defensive perimeter", 510 + min(stone, 10)))
            if self._has_upgrade_or_repair(turn):
                goals.append(Goal("upgrade-repair", "upgrade or repair the most valuable building", 700))

        if turn.phase_task or any(task.valid and task.cooldown == 0 for task in turn.tasks):
            goals.append(Goal("self-evolution-task", "execute a task-point or active sandbox task", 560))
        if self._treasure_ready(turn):
            goals.append(Goal("treasure", "solve the long-context treasure", 575))
        if self._has_usable_item(turn):
            goals.append(Goal("use-items", "use a timely consumable or summon order", 430))
        if self._has_ore_to_sell(turn):
            goals.append(Goal("trade", "sell gathered ore for the best current price", 390))
        if turn.is_day and self._needs_resources(turn):
            goals.append(Goal("collect", "collect the resource needed by the next method", 300))
        if turn.is_day and turn.gold >= 10 and turn.neutral_positions("weaponShop"):
            goals.append(Goal("shop", "buy a needed voucher, repair item, or task item", 275))
        if self._has_stranded_wall(turn):
            goals.append(Goal("remove-wall", "remove a stranded wall to reopen a route", 180))
        if self._needs_drop(turn):
            goals.append(Goal("drop-junk", "free one backpack slot for a high-value resource", 120))
        # 始终追加 safe-positioning 作为低优先级 fallback，确保每个角色至少有候选
        goals.append(Goal("safe-positioning", "make a safe non-blocking move", 10))
        return sorted(goals, key=lambda goal: goal.priority, reverse=True)

    def _choose_plan(self, turn: Turn) -> tuple[CommandMap, Plan]:
        goals = self._goals(turn)
        deadline = time.perf_counter() + PLANNING_BUDGET_SECONDS
        best: Plan | None = None
        best_lower = float("-inf")
        for goal in goals:
            if time.perf_counter() >= deadline:
                break
            for method in self._methods_for_goal(turn, goal):
                if time.perf_counter() >= deadline:
                    break
                for plan in self._plans_for_method(turn, method, deadline):
                    # This is the branch-and-bound kill step.  The upper bound
                    # assumes ideal, collision-free super-hero cooperation.
                    if plan.upper_bound <= best_lower:
                        continue
                    if best is None or plan.lower_bound > best_lower:
                        best = plan
                        best_lower = plan.lower_bound
        if best is None:
            # 兜底：为每个存活角色生成有用命令，避免空回合
            fg = Goal("fallback", "emergency safe move", 0)
            commands: CommandMap = {}
            station = turn.station()
            for role in turn.controllable():
                # 优先走向最近的资源点
                mine = self._best_mine(turn, role) if role.kind == WORKER and not role.backpack_full else None
                if mine is not None:
                    step = self._step_to_stand(turn, role, mine)
                    if step:
                        commands[role.unit_id] = move_command(step)
                        continue
                # 其次走向基地
                if station is not None and distance(role.pos, station.pos) > 2:
                    step = self._step_to_stand(turn, role, station.pos)
                    if step:
                        commands[role.unit_id] = move_command(step)
                        continue
                # 只有 worker 才能执行 remove 命令
                if role.kind == WORKER:
                    wall_to_remove = self._adjacent_removable_wall(turn, role)
                    if wall_to_remove is not None:
                        commands[role.unit_id] = remove_command(wall_to_remove)
                        continue
                # pioneer 尝试走向任务点
                if role.kind == PIONEER:
                    task_step = self._pioneer_task_step(turn, role)
                    if task_step is not None:
                        commands[role.unit_id] = move_command(task_step)
                        continue
                commands[role.unit_id] = {}
            return commands, Plan(fg, Method(fg, "fallback", (), 0), commands, 0, 0)
        # 确保所有存活角色都有命令
        result_commands = dict(best.commands)
        station = turn.station()
        for role in turn.controllable():
            if role.unit_id not in result_commands:
                # 夜间优先走向武器塔
                if not turn.is_day and turn.weapons():
                    nearest_weapon = min(turn.weapons(), key=lambda w: distance(role.pos, w.pos))
                    step = self._step_to_stand(turn, role, nearest_weapon.pos)
                    if step:
                        result_commands[role.unit_id] = move_command(step)
                        continue
                # 白天 worker 采集，pioneer 走向任务点
                if role.kind == WORKER and not role.backpack_full:
                    mine = self._best_mine(turn, role)
                    if mine:
                        cmd = self._collect_or_move(turn, role, mine)
                        if cmd:
                            result_commands[role.unit_id] = cmd
                            continue
                if role.kind == PIONEER:
                    task_step = self._pioneer_task_step(turn, role)
                    if task_step:
                        result_commands[role.unit_id] = move_command(task_step)
                        continue
                # 默认待命
                result_commands[role.unit_id] = {}
        return result_commands, best

    # ----- Level 2: methods for each goal

    def _methods_for_goal(self, turn: Turn, goal: Goal) -> list[Method]:
        if goal.goal_id in {"defend", "night-guard"}:
            return self._defense_methods(turn, goal)
        if goal.goal_id == "build-weapons":
            return self._build_methods(turn, goal, TOWER_TYPES)
        if goal.goal_id == "build-walls":
            return self._wall_methods(turn, goal)
        if goal.goal_id in {"save-base", "upgrade-repair"}:
            return self._maintenance_methods(turn, goal)
        if goal.goal_id == "collect":
            return self._collect_methods(turn, goal)
        if goal.goal_id == "trade":
            return self._trade_methods(turn, goal)
        if goal.goal_id == "shop":
            return self._shop_methods(turn, goal)
        if goal.goal_id == "self-evolution-task":
            return self._task_methods(turn, goal)
        if goal.goal_id == "treasure":
            return self._treasure_methods(turn, goal)
        if goal.goal_id == "use-items":
            return self._item_methods(turn, goal)
        if goal.goal_id == "remove-wall":
            return self._remove_methods(turn, goal)
        if goal.goal_id == "drop-junk":
            return self._drop_methods(turn, goal)
        return self._safe_methods(turn, goal)

    def _build_methods(self, turn: Turn, goal: Goal, kinds: tuple[str, ...]) -> list[Method]:
        if kinds == TOWER_TYPES:
            existing = {unit.pos for unit in turn.weapons()}
            targets = [pos for pos in self._tower_sites(turn) if pos not in existing]
            names = list(TOWER_TYPES)
            targets = [(pos, names[index % len(names)]) for index, pos in enumerate(targets)]
        else:
            targets = []
        methods: list[Method] = []
        for target, name in targets[:3]:
            for worker in turn.workers():
                command = self._build_or_move(turn, worker, target, name)
                if command is not None:
                    assignments = [self._assignment(worker.unit_id, command, value=45)]
                    # The old log shows one worker doing construction while
                    # the other spends the whole daytime walking or mining.
                    # After round 130, keep the builder and give the other
                    # worker a concurrent resource task when possible.
                    for support in turn.workers():
                        if support.unit_id == worker.unit_id or support.backpack_full:
                            continue
                        mine = self._best_mine(turn, support)
                        support_command = self._collect_or_move(turn, support, mine) if mine else None
                        if support_command is not None:
                            assignments.append(self._assignment(support.unit_id, support_command, value=16))
                    methods.append(Method(goal, f"worker {worker.unit_id} builds {name} with parallel support", tuple(assignments), 75 + 18 * (len(assignments) - 1)))
        return methods

    def _wall_methods(self, turn: Turn, goal: Goal) -> list[Method]:
        targets = [pos for pos in self._missing_wall_targets(turn)]
        methods: list[Method] = []
        for target in targets[:8]:
            for worker in turn.workers():
                if worker.count(WALL_MATERIAL) <= 0:
                    continue
                command = self._build_or_move(turn, worker, target, WALL)
                if command is not None:
                    assignments = [self._assignment(worker.unit_id, command, value=35)]
                    for support in turn.workers():
                        if support.unit_id == worker.unit_id or support.backpack_full:
                            continue
                        mine = self._best_mine(turn, support)
                        support_command = self._collect_or_move(turn, support, mine) if mine else None
                        if support_command is not None:
                            assignments.append(self._assignment(support.unit_id, support_command, value=16))
                    methods.append(Method(goal, f"worker {worker.unit_id} builds wall with parallel support", tuple(assignments), 55 + 18 * (len(assignments) - 1)))
        return methods

    def _collect_methods(self, turn: Turn, goal: Goal) -> list[Method]:
        methods: list[Method] = []
        parallel: list[Assignment] = []
        for worker in turn.workers():
            if worker.backpack_full:
                continue
            mine = self._best_mine(turn, worker)
            if mine is None:
                continue
            command = self._collect_or_move(turn, worker, mine)
            if command is not None:
                parallel.append(self._assignment(worker.unit_id, command, value=16))
                methods.append(Method(goal, f"worker {worker.unit_id} mines {turn.zones.get(mine, 'ore')}", (self._assignment(worker.unit_id, command, value=16),), 28))
        if len(parallel) > 1:
            methods.append(Method(goal, "workers mine in parallel", tuple(parallel), 28 + 18 * (len(parallel) - 1)))
        return methods

    def _trade_methods(self, turn: Turn, goal: Goal) -> list[Method]:
        vendor = self._closest_neutral(turn, "vendor")
        if vendor is None:
            return []
        methods: list[Method] = []
        parallel: list[Assignment] = []
        for role in turn.controllable():
            carried = [ore for ore in ORE_TYPES if role.count(ore)]
            if not carried:
                continue
            ore = max(carried, key=lambda item: turn.vendor_prices.get(item, 1))
            if distance(role.pos, vendor) <= 1:
                command = sell_command(ore, role.count(ore))
            else:
                step = self._step_to_stand(turn, role, vendor)
                command = move_command(step) if step else None
            if command:
                parallel.append(self._assignment(role.unit_id, command, value=30))
                methods.append(Method(goal, f"role {role.unit_id} sells {ore}", (self._assignment(role.unit_id, command, value=30),), 42))
        if len(parallel) > 1:
            methods.append(Method(goal, "ore carriers trade in parallel", tuple(parallel), 42 + 18 * (len(parallel) - 1)))
        return methods

    def _shop_methods(self, turn: Turn, goal: Goal) -> list[Method]:
        shop = self._closest_neutral(turn, "weaponShop")
        if shop is None:
            return []
        item = self._best_shop_item(turn)
        if item is None or turn.gold < item[1]:
            return []
        methods: list[Method] = []
        for role in turn.controllable():
            if role.backpack_full:
                continue
            if distance(role.pos, shop) <= 1:
                command = buy_command(item[0])
            else:
                step = self._step_to_stand(turn, role, shop)
                command = move_command(step) if step else None
            if command:
                methods.append(Method(goal, f"role {role.unit_id} buys {item[0]}", (self._assignment(role.unit_id, command, value=22),), 32))
        return methods

    def _task_methods(self, turn: Turn, goal: Goal) -> list[Method]:
        pioneer = turn.pioneers()[0] if turn.pioneers() else None
        if pioneer is None:
            return []
        if turn.phase_task.strip() and turn.llm_resp.strip():
            return [Method(goal, "submit the latest LLM answer", (self._assignment(pioneer.unit_id, submit_answer_command(turn.llm_resp.strip()), value=90),), 110)]
        # 最近 10 轮内已接受过任务，不再生成 acceptTask 方法
        last_accept = self.state.last_accept_task_round.get(pioneer.unit_id, -100)
        if turn.round_no - last_accept < 10:
            return []
        tasks = [task for task in turn.tasks if task.valid and task.cooldown == 0]
        methods: list[Method] = []
        for task in sorted(tasks, key=lambda item: distance(pioneer.pos, item.position)):
            if distance(pioneer.pos, task.position) <= 1:
                command = accept_task_command()
            else:
                step = self._step_to_stand(turn, pioneer, task.position)
                command = move_command(step) if step else None
            if command:
                methods.append(Method(goal, f"pioneer visits {task.task_type}", (self._assignment(pioneer.unit_id, command, value=task.score_reward + task.gold_reward),), 95))
        return methods

    def _treasure_methods(self, turn: Turn, goal: Goal) -> list[Method]:
        pioneer = turn.pioneers()[0] if turn.pioneers() else None
        target = self.state.treasure_target
        items = self.state.treasure_items
        if pioneer is None or target is None or not items:
            return []
        if any(pioneer.count(item) < items.count(item) for item in items):
            return []
        if distance(pioneer.pos, target) <= 1:
            command = summon_treasure_command(target, items)
        else:
            step = self._step_to_stand(turn, pioneer, target)
            command = move_command(step) if step else None
        if command:
            return [Method(goal, "pioneer reaches altar and sacrifices exact items", (self._assignment(pioneer.unit_id, command, value=130),), 160)]
        return []

    def _maintenance_methods(self, turn: Turn, goal: Goal) -> list[Method]:
        methods: list[Method] = []
        buildings = tuple(unit for unit in turn.ours if unit.kind in (STATION, *TOWER_TYPES, WALL) and unit.alive)
        for role in turn.controllable():
            for item in role.backpack:
                target = self._voucher_target(item, buildings, turn)
                if target is None:
                    continue
                if distance(role.pos, target.pos) <= 1:
                    command = use_command(item, target.pos)
                else:
                    step = self._step_to_stand(turn, role, target.pos)
                    command = move_command(step) if step else None
                if command:
                    methods.append(Method(goal, f"role {role.unit_id} uses {item}", (self._assignment(role.unit_id, command, value=90),), 120))
        for role in turn.controllable():
            if role.count("Medicine") and role.health < role.max_health() * 0.55:
                methods.append(Method(goal, f"role {role.unit_id} heals", (self._assignment(role.unit_id, use_command("Medicine"), value=65),), 80))
        for wall in turn.walls():
            if wall.health >= wall.max_health() * 0.75:
                continue
            for role in turn.controllable():
                if not role.count("WallFixer"):
                    continue
                if distance(role.pos, wall.pos) <= 1:
                    command = use_command("WallFixer", wall.pos)
                else:
                    step = self._step_to_stand(turn, role, wall.pos)
                    command = move_command(step) if step else None
                if command:
                    methods.append(Method(goal, f"role {role.unit_id} repairs wall", (self._assignment(role.unit_id, command, value=70),), 90))
        return methods

    def _item_methods(self, turn: Turn, goal: Goal) -> list[Method]:
        methods: list[Method] = []
        robots = [robot for robot in turn.robots if robot.health > 0]
        for role in turn.controllable():
            if role.count("Medicine") and role.health < role.max_health() * 0.65:
                methods.append(Method(goal, "heal an injured hero", (self._assignment(role.unit_id, use_command("Medicine"), value=60),), 70))
            if not turn.is_day and robots:
                cluster = self._best_robot_cluster(robots)
                if role.count("Bomb"):
                    methods.append(Method(goal, "bomb the densest robot cluster", (self._assignment(role.unit_id, use_command("Bomb", cluster), value=80),), 100))
                if role.count("DizzyWeapon"):
                    methods.append(Method(goal, "stun the densest robot cluster", (self._assignment(role.unit_id, use_command("DizzyWeapon", cluster), value=70),), 90))
            if turn.is_day and self.state.summons_used_today < 10:
                for item in ("BossRobotSummonOrder", "LargeRobotSummonOrder", "MiddleRobotSummonOrder", "SmallRobotSummonOrder"):
                    if role.count(item):
                        methods.append(Method(goal, f"use one {item}", (self._assignment(role.unit_id, use_command(item), value=15),), 22))
                        break
        return methods

    def _remove_methods(self, turn: Turn, goal: Goal) -> list[Method]:
        target = next((wall for wall in turn.walls() if wall.pos not in self._wall_order(turn)), None)
        if target is None:
            return []
        return [
            Method(goal, f"worker removes wall {target.unit_id}", (self._assignment(worker.unit_id, remove_command(target.pos), value=12),), 20)
            for worker in turn.workers()
            if distance(worker.pos, target.pos) <= 1
        ]

    def _adjacent_removable_wall(self, turn: Turn, role: Unit) -> Pos | None:
        """查找角色相邻的墙，优先选择不在预期墙位中的墙（多余墙），其次选择任何墙。"""
        wall_positions = {wall.pos for wall in turn.walls()}
        expected = set(self._wall_order(turn))
        extra_walls = wall_positions - expected
        for dx, dy in _NEIGHBOUR_STEPS:
            neighbor = Pos(role.pos.x + dx, role.pos.y + dy)
            if neighbor in extra_walls:
                return neighbor
        for dx, dy in _NEIGHBOUR_STEPS:
            neighbor = Pos(role.pos.x + dx, role.pos.y + dy)
            if neighbor in wall_positions:
                return neighbor
        return None

    def _drop_methods(self, turn: Turn, goal: Goal) -> list[Method]:
        methods: list[Method] = []
        for role in turn.controllable():
            if not role.backpack_full:
                continue
            droppable = [item for item in role.backpack if item not in _TREASURE_ITEMS]
            if droppable:
                item = min(droppable, key=lambda name: turn.vendor_prices.get(name, 0))
                methods.append(Method(goal, f"role {role.unit_id} drops {item}", (self._assignment(role.unit_id, drop_command(item), value=4),), 8))
        return methods

    def _safe_methods(self, turn: Turn, goal: Goal) -> list[Method]:
        station = turn.station()
        if station is None:
            return []
        methods: list[Method] = []
        for role in turn.controllable():
            # 已在基地附近（距离 ≤ 2）则待命，避免与其他目标交替导致振荡
            if distance(role.pos, station.pos) <= 2:
                methods.append(Method(goal, "hold position near base", (self._assignment(role.unit_id, {}, value=0),), 1))
                continue
            step = self._step_to_stand(turn, role, station.pos)
            if step:
                methods.append(Method(goal, "take a safe step toward base", (self._assignment(role.unit_id, move_command(step), value=1),), 2))
            elif role.kind == WORKER:
                # 只有 worker 才能执行 remove 命令
                wall_to_remove = self._adjacent_removable_wall(turn, role)
                if wall_to_remove is not None:
                    methods.append(Method(goal, "remove blocking wall", (self._assignment(role.unit_id, remove_command(wall_to_remove), value=5),), 5))
                else:
                    methods.append(Method(goal, "hold position", (self._assignment(role.unit_id, {}, value=0),), 1))
            else:
                methods.append(Method(goal, "hold position", (self._assignment(role.unit_id, {}, value=0),), 1))
        return methods

    def _defense_methods(self, turn: Turn, goal: Goal) -> list[Method]:
        heroes = turn.controllable()
        weapons = turn.weapons()
        if not heroes or not weapons:
            return []
        # 受伤且有药品的英雄优先治疗
        heal_assignments: list[Assignment] = []
        for hero in heroes:
            if hero.count("Medicine") and hero.health < hero.max_health() * 0.55:
                heal_assignments.append(self._assignment(hero.unit_id, use_command("Medicine"), value=65))
        assignments_by_weapon: list[list[tuple[Unit, Unit]]] = []
        for weapon in weapons:
            choices = sorted(heroes, key=lambda hero: (distance(hero.pos, weapon.pos), hero.unit_id))
            assignments_by_weapon.append([(hero, weapon) for hero in choices[:3]])
        methods: list[Method] = []
        # Distinct controller permutations create distinct conflict-resolution
        # methods.  At most 3! combinations are possible.
        for pairing in product(*assignments_by_weapon):
            if len({hero.unit_id for hero, _ in pairing}) != len(pairing):
                continue
            assignments: list[Assignment] = []
            gain = 0.0
            used_targets: set[Pos] = set()
            for hero, weapon in pairing:
                command_map: CommandMap = {}
                if distance(hero.pos, weapon.pos) <= 1:
                    targets = self._attack_targets(turn, weapon, avoid=used_targets)
                    if targets and weapon.cooldown <= 0:
                        command_map[weapon.unit_id] = attack_command(hero.unit_id, targets)
                        # controller 本回合不能执行其他动作，显式占位
                        command_map[hero.unit_id] = {}
                        gain += sum(ROBOT_SCORE.get(robot.role_type, 1) for robot in turn.robots if robot.pos in targets)
                        used_targets.update(targets)
                    else:
                        command_map[hero.unit_id] = {}
                else:
                    step = self._step_to_stand(turn, hero, weapon.pos)
                    if step:
                        command_map[hero.unit_id] = move_command(step)
                    else:
                        continue
                assignments.append(Assignment(weapon.unit_id, (command_map,), frozenset((weapon.unit_id, hero.unit_id)), 15 + gain))
            # 附加治疗分配
            assignments.extend(heal_assignments)
            if assignments:
                methods.append(Method(goal, "assign distinct heroes to weapons", tuple(assignments), max(20, gain + 25)))
        return methods

    # ----- Level 3: enumerate, resolve, score, and prune concrete plans

    def _plans_for_method(self, turn: Turn, method: Method, deadline: float) -> Iterable[Plan]:
        if not method.assignments:
            yield Plan(method.goal, method, {}, method.goal.priority, method.goal.priority + method.ideal_gain)
            return
        choice_lists = [assignment.choices for assignment in method.assignments]
        for combo in product(*choice_lists):
            if time.perf_counter() >= deadline:
                return
            locks: set[int] = set()
            merged: CommandMap = {}
            valid = True
            for assignment, choice in zip(method.assignments, combo):
                if locks.intersection(assignment.locks):
                    valid = False
                    break
                locks.update(assignment.locks)
                for key, command in choice.items():
                    if key in merged:
                        valid = False
                        break
                    merged[key] = command
                if not valid:
                    break
            if not valid:
                continue
            if any(
                self.state.action_blocked(unit_id, command, turn.round_no)
                for unit_id, command in merged.items()
            ):
                continue
            # Try several yielding orders.  A lower-priority role gives way to
            # a higher-priority role when two paths compete for one cell.
            move_ids = tuple(
                key for key, command in merged.items()
                if command.get("action") == "move"
            )
            orders = (move_ids, tuple(reversed(move_ids)))
            for order in orders:
                resolved, conflicts = self._resolve_collisions(turn, merged, order)
                lower = method.goal.priority + sum(self._action_value(command) for command in resolved.values())
                lower += 18 if not conflicts else -45 * len(conflicts)
                upper = method.goal.priority + method.ideal_gain + max(0.0, sum(self._action_value(command) for command in merged.values()))
                yield Plan(method.goal, method, resolved, lower, max(lower, upper), tuple(conflicts))

    def _resolve_collisions(self, turn: Turn, commands: CommandMap, order: tuple[int, ...]) -> tuple[CommandMap, list[str]]:
        resolved: CommandMap = {}
        conflicts: list[str] = []
        by_role = {role.unit_id: role for role in turn.controllable()}
        moves: dict[int, Pos] = {}
        for unit_id, command in commands.items():
            if command.get("action") != "move":
                continue
            targets = command.get("targetPos") or []
            if len(targets) != 1:
                conflicts.append(f"role {unit_id} has invalid move arity")
                continue
            try:
                moves[unit_id] = Pos.load(targets[0])
            except (TypeError, ValueError, KeyError):
                conflicts.append(f"role {unit_id} has invalid move target")
        accepted: dict[int, Pos] = {}
        current = {role.unit_id: role.pos for role in turn.controllable()}
        ordered_ids = list(order) + [unit_id for unit_id in moves if unit_id not in order]
        for unit_id in ordered_ids:
            role = by_role.get(unit_id)
            if role is None:
                conflicts.append(f"unit {unit_id} cannot move")
                continue
            target = moves[unit_id]
            if not turn.land(target) or (target in turn.zones and turn.zones[target] != LAND):
                conflicts.append(f"role {unit_id} hit a map obstacle")
                continue
            if any(target == other.pos for other in turn.ours if other.alive and other.unit_id != unit_id and other.kind not in HERO_TYPES):
                conflicts.append(f"role {unit_id} hit a building")
                continue
            if any(target == robot.pos for robot in turn.robots if robot.health > 0):
                conflicts.append(f"role {unit_id} met a robot")
                continue
            other = next((other_id for other_id, pos in current.items() if other_id != unit_id and pos == target), None)
            if other is not None and other not in accepted:
                # If the other role intends the reverse move, both must stop.
                if moves.get(other) == role.pos:
                    conflicts.append(f"roles {unit_id} and {other} attempted a swap")
                else:
                    conflicts.append(f"role {unit_id} yielded to role {other}")
                continue
            if target in accepted.values():
                conflicts.append(f"role {unit_id} yielded a contested cell")
                continue
            accepted[unit_id] = target
        for unit_id, command in commands.items():
            if command.get("action") != "move" or unit_id in accepted:
                resolved[unit_id] = command
        return resolved, conflicts

    # ----- Small, reusable game-rule helpers

    def _assignment(self, owner_id: int, command: Command, *, value: float = 0.0, locks: Iterable[int] = ()) -> Assignment:
        return Assignment(owner_id, ({owner_id: command},), frozenset(set(locks) or {owner_id}), value)

    def _action_value(self, command: Command) -> float:
        action = command.get("action")
        if action == "attack":
            return 24
        if action in {"build", "use", "summonTreasure", "submitAnswer"}:
            return 18
        if action in {"sell", "buy", "acceptTask", "collect"}:
            return 12
        if action == "move":
            return 3
        return 1

    def _step_to_stand(self, turn: Turn, role: Unit, target: Pos) -> Pos | None:
        if distance(role.pos, target) <= 1:
            return None
        blocked = turn.blocked(role)
        prev_pos = self.state.last_pos.get(role.unit_id)
        prev_prev = self.state.prev_prev_pos.get(role.unit_id)
        candidates = [pos for pos in turn.at_distance_one(target) if turn.land(pos) and pos not in blocked]
        candidates.sort(key=lambda pos: (distance(role.pos, pos), pos.x, pos.y))
        for candidate in candidates:
            step = next_step(turn, role, candidate, blocked)
            if step is None:
                continue
            # 振荡检测：优先跳过会回到上一轮或上上轮位置的步
            if prev_pos is not None and step == prev_pos and prev_pos != role.pos:
                continue
            if prev_prev is not None and step == prev_prev and prev_prev != role.pos and prev_prev != prev_pos:
                continue
            return step
        # 所有候选都触发振荡检测时，原地待命而非回退（回退等于放弃振荡检测）
        return None

    def _collect_or_move(self, turn: Turn, role: Unit, mine: Pos) -> Command | None:
        if distance(role.pos, mine) <= 1:
            # 检测是否在同一矿点采集过久（可能已枯竭）
            tracker = self.state.collect_tracker.get(role.unit_id)
            if tracker and tracker[0] == mine and tracker[1] >= 3:
                # 尝试寻找其他矿点
                other = self._best_mine_excluding(turn, role, mine)
                if other is not None:
                    self.state.collect_tracker[role.unit_id] = (other, 0)
                    if distance(role.pos, other) <= 1:
                        return collect_command(other)
                    step = self._step_to_stand(turn, role, other)
                    return move_command(step) if step else None
            self.state.collect_tracker[role.unit_id] = (mine, (tracker[1] + 1) if tracker and tracker[0] == mine else 1)
            return collect_command(mine)
        step = self._step_to_stand(turn, role, mine)
        return move_command(step) if step else None

    def _best_mine_excluding(self, turn: Turn, role: Unit, exclude: Pos) -> Pos | None:
        wanted = "stone" if self._missing_wall_targets(turn) else None
        mines = [pos for pos in turn.resource_mines(wanted) if pos != exclude]
        if not mines:
            return None
        mines.sort(key=lambda pos: (-turn.vendor_prices.get(turn.zones.get(pos, ""), 1), distance(role.pos, pos), pos.x, pos.y))
        return mines[0]

    def _build_or_move(self, turn: Turn, role: Unit, target: Pos, name: str) -> Command | None:
        if distance(role.pos, target) <= 1:
            return build_command(target, name)
        step = next_step(turn, role, target) if turn.land(target) else self._step_to_stand(turn, role, target)
        return move_command(step) if step else None

    def _best_mine(self, turn: Turn, role: Unit) -> Pos | None:
        wanted = "stone" if self._missing_wall_targets(turn) else None
        mines = list(turn.resource_mines(wanted))
        if not mines:
            return None
        mines.sort(key=lambda pos: (-turn.vendor_prices.get(turn.zones.get(pos, ""), 1), distance(role.pos, pos), pos.x, pos.y))
        return mines[0]

    def _closest_neutral(self, turn: Turn, kind: str) -> Pos | None:
        positions = turn.neutral_positions(kind)
        if not positions:
            return None
        roles = turn.controllable()
        origin = roles[0].pos if roles else (turn.station().pos if turn.station() else Pos(0, 0))
        return min(positions, key=lambda pos: (distance(origin, pos), pos.x, pos.y))

    def _has_ore_to_sell(self, turn: Turn) -> bool:
        return any(unit.count(ore) for unit in turn.controllable() for ore in ORE_TYPES) and bool(turn.neutral_positions("vendor"))

    def _needs_resources(self, turn: Turn) -> bool:
        return bool(turn.resource_mines()) and any(not worker.backpack_full for worker in turn.workers())

    def _missing_wall_targets(self, turn: Turn) -> tuple[Pos, ...]:
        existing = {wall.pos for wall in turn.walls()}
        return tuple(pos for pos in self._wall_order(turn) if pos not in existing)

    def _has_stranded_wall(self, turn: Turn) -> bool:
        expected = set(self._wall_order(turn))
        return any(wall.pos not in expected for wall in turn.walls())

    def _has_upgrade_or_repair(self, turn: Turn) -> bool:
        buildings = tuple(unit for unit in turn.ours if unit.kind in (STATION, *TOWER_TYPES, WALL) and unit.alive)
        voucher_names = {item for unit in turn.controllable() for item in unit.backpack if "UpgradeVoucher" in item or item == "WallFixer"}
        return bool(voucher_names) or any(unit.health < unit.max_health() * 0.75 for unit in buildings)

    def _has_usable_item(self, turn: Turn) -> bool:
        for role in turn.controllable():
            if role.count("Medicine") and role.health < role.max_health() * 0.65:
                return True
            if not turn.is_day and any(role.count(item) for item in ("Bomb", "DizzyWeapon")) and any(robot.health > 0 for robot in turn.robots):
                return True
            if turn.is_day and any(role.count(item) for item in ("SmallRobotSummonOrder", "MiddleRobotSummonOrder", "LargeRobotSummonOrder", "BossRobotSummonOrder")):
                return True
        return False

    def _needs_drop(self, turn: Turn) -> bool:
        return any(role.backpack_full for role in turn.controllable())

    def _voucher_target(self, item: str, buildings: tuple[Unit, ...], turn: Turn) -> Unit | None:
        if item == "StationUpgradeVoucher1":
            return next((unit for unit in buildings if unit.kind == STATION and unit.level == 1), None)
        if item == "StationUpgradeVoucher2":
            return next((unit for unit in buildings if unit.kind == STATION and unit.level == 2), None)
        if item == "WeaponUpgradeVoucher1":
            return next((unit for unit in buildings if unit.kind in TOWER_TYPES and unit.level == 1), None)
        if item == "WeaponUpgradeVoucher2":
            return next((unit for unit in buildings if unit.kind in TOWER_TYPES and unit.level == 2), None)
        if item == "WallUpgradeVoucher1":
            return next((unit for unit in buildings if unit.kind == WALL and unit.level == 1), None)
        if item == "WallUpgradeVoucher2":
            return next((unit for unit in buildings if unit.kind == WALL and unit.level == 2), None)
        return None

    def _best_shop_item(self, turn: Turn) -> tuple[str, int] | None:
        available = {item.name: item.price for item in turn.weapon_shop if item.name}
        listed_items = bool(available)
        if not listed_items:
            available = dict(SHOP_PRICES)
        buildings = tuple(unit for unit in turn.ours if unit.kind in (STATION, *TOWER_TYPES, WALL) and unit.alive)
        for name in ("StationUpgradeVoucher1", "WeaponUpgradeVoucher1", "WallUpgradeVoucher1", "WallFixer"):
            if listed_items and name not in available:
                continue
            price = available.get(name, SHOP_PRICES.get(name, 0))
            if name.startswith("Station") and any(unit.kind == STATION and unit.level == 1 for unit in buildings):
                return name, price
            if name.startswith("Weapon") and any(unit.kind in TOWER_TYPES and unit.level == 1 for unit in buildings):
                return name, price
            if name == "WallUpgradeVoucher1" and any(unit.kind == WALL and unit.level == 1 for unit in buildings):
                return name, price
            if name == "WallFixer" and any(unit.kind == WALL and unit.health < unit.max_health() * 0.75 for unit in buildings):
                return name, price
        target = self.state.treasure_target
        if target and self.state.treasure_items:
            for item in self.state.treasure_items:
                if item not in available:
                    continue
                if not any(role.count(item) for role in turn.controllable()):
                    return item, available[item]
        return None

    def _treasure_ready(self, turn: Turn) -> bool:
        return not self.state.treasure_claimed and self.state.treasure_target is not None and bool(self.state.treasure_items)

    def _best_robot_cluster(self, robots: list[Any]) -> Pos:
        return min(robots, key=lambda robot: (-sum(distance(robot.pos, other.pos) <= 1 for other in robots), robot.health, robot.robot_id)).pos

    def _attack_targets(self, turn: Turn, weapon: Unit, *, avoid: Iterable[Pos] = ()) -> list[Pos]:
        candidates = [robot for robot in turn.robots if robot.health > 0 and distance(weapon.pos, robot.pos) <= weapon.range_of_attack()]
        if not candidates:
            candidates = [enemy for enemy in turn.enemies if enemy.alive and distance(weapon.pos, enemy.pos) <= weapon.range_of_attack()]
        if weapon.kind != "rocket":
            candidates = [unit for unit in candidates if self._line_clear(turn, weapon.pos, unit.pos)]
        avoided = set(avoid)
        unclaimed = [unit for unit in candidates if unit.pos not in avoided]
        required = 1 if weapon.kind == "railgun" else max(1, weapon.level)
        if len(unclaimed) >= required:
            candidates = unclaimed
        candidates.sort(key=lambda unit: (-ROBOT_SCORE.get(getattr(unit, "role_type", getattr(unit, "kind", "")), 0), distance(weapon.pos, unit.pos), getattr(unit, "robot_id", getattr(unit, "unit_id", 0))))
        if weapon.kind == "railgun":
            return [candidates[0].pos] if candidates else []
        limit = min(max(1, weapon.level), len(candidates))
        if len(candidates) < max(1, weapon.level):
            return []
        chosen: list[Pos] = []
        for candidate in candidates:
            if len(chosen) >= limit:
                break
            if weapon.kind == "gatling" and chosen and not all(_angle_at_most_90(weapon.pos, candidate.pos, pos) for pos in chosen):
                continue
            chosen.append(candidate.pos)
        return chosen if len(chosen) == limit else []

    def _line_clear(self, turn: Turn, origin: Pos, target: Pos) -> bool:
        """Conservative line-of-fire check for gatling and railgun."""

        steps = max(abs(target.x - origin.x), abs(target.y - origin.y))
        blocked = set(turn.blocked())
        blocked.discard(origin)
        blocked.discard(target)
        for index in range(1, steps):
            x = round(origin.x + (target.x - origin.x) * index / steps)
            y = round(origin.y + (target.y - origin.y) * index / steps)
            if Pos(x, y) in blocked:
                return False
        return True

    # ----- Map geometry from the original implementation, retained and made
    # reusable by all methods.

    def _tower_sites(self, turn: Turn) -> tuple[Pos, ...]:
        station = turn.station()
        if station is None:
            return ()
        footprint = turn.footprint(station)
        cells = [pos for pos in _cells_at_distance(station.pos, 1) if turn.land(pos)]
        cells.sort(key=lambda pos: (_footprint_distance(pos, footprint), pos.x, pos.y))
        return tuple(cells[:3])

    def _wall_order(self, turn: Turn) -> tuple[Pos, ...]:
        station = turn.station()
        if station is None:
            return ()
        footprint = turn.footprint(station)
        xs = [pos.x for pos in footprint]
        ys = [pos.y for pos in footprint]
        xmin, xmax = min(xs), max(xs)
        ymin, ymax = min(ys), max(ys)
        order = [
            *(Pos(x, ymin - 2) for x in range(xmax + 2, xmin - 3, -1)),
            *(Pos(xmin - 2, y) for y in range(ymin - 1, ymax + 2)),
            *(Pos(x, ymax + 2) for x in range(xmin - 2, xmax + 3)),
            *(Pos(xmax + 2, y) for y in range(ymax + 1, ymin - 2, -1)),
        ]
        entrance = Pos(xmax + 2, ymin - 1)
        return tuple(pos for pos in order if pos != entrance and turn.land(pos))

    def _task_prompt(self, turn: Turn) -> str:
        if self.state.llm_calls >= 3:
            return ""
        if turn.phase_task.strip() and not turn.llm_resp.strip():
            self.state.llm_calls += 1
            return (
                "你正在执行《未来战争》的自进化任务。请阅读任务原文，必要时给出可在无网络沙盒中执行的最短探索命令，"
                "并在回答中最后单独给出可提交的最终答案。不要臆造外部信息。\n任务原文：\n" + turn.phase_task
            )
        if self.state.folk_history and not self._treasure_ready(turn) and not turn.phase_task.strip():
            self.state.llm_calls += 1
            return (
                "请根据累计民间传闻推断《未来战争》祭坛宝藏信息。只输出一行："
                "coordinate=(x,y); items=[英文任务用品名,...]。无法确定时保留空列表，不要猜测。\n"
                + self.state.folk_history
            )
        return ""

    def _task_command(self, turn: Turn) -> str:
        # The judge accepts an empty command.  If the model returned a fenced
        # shell/python snippet, execute only that snippet during an active task.
        if not turn.phase_task.strip() or not turn.llm_resp.strip():
            return ""
        match = re.search(r"```(?:bash|sh|shell|python)?\s*\n?([^`]+?)```", turn.llm_resp, re.I)
        if not match:
            return ""
        command = match.group(1).strip().splitlines()[0].strip()
        return command if len(command) <= 2000 else ""


def _angle_at_most_90(origin: Pos, first: Pos, second: Pos) -> bool:
    first_vector = (first.x - origin.x, first.y - origin.y)
    second_vector = (second.x - origin.x, second.y - origin.y)
    dot = first_vector[0] * second_vector[0] + first_vector[1] * second_vector[1]
    return dot >= 0


def _cells_at_distance(station_pos: Pos, radius: int) -> tuple[Pos, ...]:
    footprint = (station_pos, Pos(station_pos.x + 1, station_pos.y), Pos(station_pos.x, station_pos.y - 1), Pos(station_pos.x + 1, station_pos.y - 1))
    xs = [pos.x for pos in footprint]
    ys = [pos.y for pos in footprint]
    cells: list[Pos] = []
    for x in range(min(xs) - radius, max(xs) + radius + 1):
        for y in range(min(ys) - radius, max(ys) + radius + 1):
            pos = Pos(x, y)
            if pos not in footprint and _footprint_distance(pos, footprint) == radius:
                cells.append(pos)
    return tuple(cells)


def _footprint_distance(pos: Pos, footprint: tuple[Pos, ...]) -> int:
    return min((distance(pos, cell) for cell in footprint), default=0)


# Compatibility helpers retained for callers that imported the old demo brain.
_TOWER_PLANNER = GoalMethodPlanPlanner()


def decide(payload: Mapping[str, Any]) -> dict[str, Any]:
    try:
        return _TOWER_PLANNER.decide(payload)
    except Exception:
        # A malformed judge payload must still receive a protocol-shaped body.
        return {"roleCommandMap": {}, "prompt": "", "executeCmd": ""}


def _day(turn: Turn, commands: CommandMap) -> None:
    _TOWER_PLANNER._legacy_day(turn, commands)


def _night(turn: Turn, commands: CommandMap) -> None:
    _TOWER_PLANNER._legacy_night(turn, commands)


def _turn_to_payload_for_compatibility(turn: Turn) -> dict[str, Any]:
    # This is only used by legacy unit tests that call _day/_night directly;
    # normal HTTP requests always use the original judge payload.
    return {
        "roundNo": turn.round_no,
        "mapInfo": {"width": turn.width, "height": turn.height, "zones": [{"pos": pos.dump(), "neutralType": kind} for pos, kind in turn.zones.items()]},
        "teamOur": {"type": turn.team_type, "teamId": turn.team_id, "goldNum": turn.gold, "totalScore": turn.score, "roles": [{"id": unit.unit_id, "pos": unit.pos.dump(), "roleType": unit.kind, "health": unit.health, "level": unit.level, "cooldown": unit.cooldown, "attackRange": unit.attack_range, "backPackCapability": unit.capacity, "backpack": list(unit.backpack)} for unit in turn.ours]},
        "teamEnemy": {"roles": []},
        "robot": {"roles": [{"id": robot.robot_id, "pos": robot.pos.dump(), "health": robot.health, "roleType": robot.role_type} for robot in turn.robots]},
    }
