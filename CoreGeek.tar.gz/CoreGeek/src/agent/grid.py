from __future__ import annotations

from heapq import heappop, heappush
from itertools import count
from typing import Iterable

from .protocol import Pos, Turn, Unit, distance

_STEPS = (
    (-1, -1), (-1, 0), (-1, 1),
    (0, -1), (0, 1),
    (1, -1), (1, 0), (1, 1),
)


def neighbours(pos: Pos) -> tuple[Pos, ...]:
    return tuple(Pos(pos.x + dx, pos.y + dy) for dx, dy in _STEPS)


def next_step(turn: Turn, moving: Unit, goal: Pos, blocked: frozenset[Pos] | None = None) -> Pos | None:
    if blocked is None:
        blocked = turn.blocked(moving)
    order = count()
    frontier: list[tuple[int, int, int, Pos]] = [
        (distance(moving.pos, goal), 0, next(order), moving.pos)
    ]
    came_from: dict[Pos, Pos] = {}
    best = {moving.pos: 0}
    seen: set[Pos] = set()

    while frontier:
        _, cost, _, current = heappop(frontier)
        if current in seen:
            continue
        if current == goal:
            return _first_step(came_from, moving.pos, goal)
        seen.add(current)
        for step in neighbours(current):
            if step in blocked or not turn.land(step):
                continue
            new_cost = cost + 1
            if new_cost >= best.get(step, new_cost + 1):
                continue
            best[step] = new_cost
            came_from[step] = current
            heappush(
                frontier,
                (
                    new_cost + distance(step, goal),
                    new_cost,
                    next(order),
                    step,
                ),
            )
    return None


def first_step_to_any(turn: Turn, moving: Unit, goals: Iterable[Pos]) -> Pos | None:
    """Return a first step to the closest reachable goal in ``goals``.

    Building, mining, selling, and task actions all need the role to stand
    next to a blocked map element.  This helper keeps that rule out of every
    individual method in the planner.
    """

    candidates = [goal for goal in goals if turn.land(goal)]
    candidates.sort(key=lambda goal: (distance(moving.pos, goal), goal.x, goal.y))
    for goal in candidates:
        step = next_step(turn, moving, goal)
        if step is not None:
            return step
    return None


def _first_step(came_from: dict[Pos, Pos], start: Pos, goal: Pos) -> Pos:
    current = goal
    while came_from[current] != start:
        current = came_from[current]
    return current
