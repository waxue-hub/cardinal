import json
import logging
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any

from .brain import decide

LOGGER = logging.getLogger(__name__)
DECISION_LOCK = threading.Lock()
MAX_REQUEST_BYTES = 2 * 1024 * 1024


class Handler(BaseHTTPRequestHandler):
    def do_POST(self) -> None:
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except (TypeError, ValueError):
            length = 0
        if length < 0 or length > MAX_REQUEST_BYTES:
            self.send_error(413, "request too large")
            return
        raw = self.rfile.read(length)
        try:
            payload = json.loads(raw.decode("utf-8"))
            # The planner keeps per-match state.  ThreadingHTTPServer is
            # useful for a responsive socket, but concurrent turns must not
            # interleave state updates or consume the same LLM budget twice.
            with DECISION_LOCK:
                response = decide(payload)
            LOGGER.info("round %s -> %s", payload.get("roundNo"), response.get("roleCommandMap", {}))
            body = json.dumps(response, ensure_ascii=False).encode("utf-8")
        except Exception:
            LOGGER.exception("decision failed")
            body = b'{"roleCommandMap":{},"prompt":"","executeCmd":""}'
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, format: str, *args: Any) -> None:
        return


def serve(port: int) -> None:
    ThreadingHTTPServer(("0.0.0.0", port), Handler).serve_forever()
